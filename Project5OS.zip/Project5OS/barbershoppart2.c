#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "common_threads.h"

#define MAX_CHAIRS 5  // Maximum chairs in the waiting room

// Shared variables and synchronization tools
int waitingCustomers = 0;         // Number of waiting customers
pthread_mutex_t mutex;            // Mutex for shared variables
pthread_cond_t barberSleep;       // Condition to wake the barber
pthread_cond_t customerReady;     // Condition to signal a customer is ready

void *barber(void *arg) {
    while (1) {
        pthread_mutex_lock(&mutex);
        // Barber waits for customers if none are in the waiting room
        while (waitingCustomers == 0) {
            printf("Barber is sleeping\n");
            pthread_cond_wait(&customerReady, &mutex);
        }
        // Serve a customer
        waitingCustomers--;
        printf("Barber is cutting hair, %d customers waiting\n", waitingCustomers);
        pthread_cond_signal(&barberSleep);  // Notify customer their turn has started
        pthread_mutex_unlock(&mutex);

        // Simulate hair cutting
        sleep(3);
    }
    return NULL;
}

void *customer(void *arg) {
    pthread_mutex_lock(&mutex);
    // Check if there are free chairs
    if (waitingCustomers < MAX_CHAIRS) {
        waitingCustomers++;
        printf("Customer arrives, %d customers waiting\n", waitingCustomers);
        pthread_cond_signal(&customerReady);  // Wake up barber if sleeping
        // Wait for the barber to start cutting
        pthread_cond_wait(&barberSleep, &mutex);
    } else {
        // Customer leaves if no chairs are available
        printf("Customer leaves, no chairs available\n");
    }
    pthread_mutex_unlock(&mutex);
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        // Ensure correct usage
        fprintf(stderr, "Usage: %s <number of customers>\n", argv[0]);
        return 1;
    }
    int numCustomers = atoi(argv[1]);

    // Initialize mutex and condition variables
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&barberSleep, NULL);
    pthread_cond_init(&customerReady, NULL);

    pthread_t barberThread;
    pthread_t customerThreads[numCustomers];

    // Start barber thread
    pthread_create(&barberThread, NULL, barber, NULL);

    // Start customer threads with random arrival times
    for (int i = 0; i < numCustomers; ++i) {
        pthread_create(&customerThreads[i], NULL, customer, NULL);
        sleep(rand() % 3); // Random delay between customer arrivals
    }

    // Wait for all customer threads to finish
    for (int i = 0; i < numCustomers; ++i) {
        pthread_join(customerThreads[i], NULL);
    }

    // Clean up resources
    pthread_cancel(barberThread); // Stop barber thread
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&barberSleep);
    pthread_cond_destroy(&customerReady);

    return 0;
}
