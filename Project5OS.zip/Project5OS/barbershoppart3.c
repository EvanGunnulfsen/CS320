#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "common_threads.h"

#define MAX_CHAIRS 5  // Number of waiting room chairs
#define NUM_BARBERS 2 // Number of barbers

// Shared variables and synchronization tools
int waitingCustomers = 0;         // Current number of waiting customers
int totalCustomers = 0;           // Total customers yet to be served
pthread_mutex_t mutex;            // Mutex to protect shared data
pthread_cond_t barberSleep;       // Condition to wake up a barber
pthread_cond_t customerReady;     // Condition to signal a customer is ready

void *barber(void *arg) {
    int barberId = *((int *)arg); // Get barber's ID

    while (1) {
        pthread_mutex_lock(&mutex);
        // Barber sleeps if no customers are waiting
        while (waitingCustomers == 0) {
            printf("Barber %d is sleeping\n", barberId);
            pthread_cond_wait(&customerReady, &mutex);
        }
        // Serve a customer
        waitingCustomers--;
        printf("Barber %d is cutting hair, %d customers waiting\n", barberId, waitingCustomers);
        pthread_cond_signal(&barberSleep); // Notify customer their turn has started
        pthread_mutex_unlock(&mutex);

        // Simulate hair cutting
        sleep(3);

        // Check if all customers are served
        pthread_mutex_lock(&mutex);
        if (waitingCustomers == 0 && totalCustomers == 0) {
            pthread_mutex_unlock(&mutex);
            break; // End barber thread
        }
        pthread_mutex_unlock(&mutex);
    }
    printf("Barber %d is done for the day.\n", barberId);
    return NULL;
}

void *customer(void *arg) {
    pthread_mutex_lock(&mutex);
    // Check if there's space in the waiting room
    if (waitingCustomers < MAX_CHAIRS) {
        waitingCustomers++;
        totalCustomers++;
        printf("Customer arrives, %d customers waiting\n", waitingCustomers);
        pthread_cond_signal(&customerReady);  // Wake up a barber if needed
        pthread_cond_wait(&barberSleep, &mutex); // Wait for barber to serve
    } else {
        // Leave if no chairs are available
        printf("Customer leaves, no chairs available\n");
    }
    pthread_mutex_unlock(&mutex);
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        // Check for proper usage
        fprintf(stderr, "Usage: %s <number of customers>\n", argv[0]);
        return 1;
    }
    int numCustomers = atoi(argv[1]);

    // Initialize mutex and condition variables
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&barberSleep, NULL);
    pthread_cond_init(&customerReady, NULL);

    pthread_t barberThreads[NUM_BARBERS];
    pthread_t customerThreads[numCustomers];
    int barberIds[NUM_BARBERS];

    // Start barber threads
    for (int i = 0; i < NUM_BARBERS; ++i) {
        barberIds[i] = i + 1; // Assign IDs to barbers
        pthread_create(&barberThreads[i], NULL, barber, &barberIds[i]);
    }

    // Start customer threads
    for (int i = 0; i < numCustomers; ++i) {
        pthread_create(&customerThreads[i], NULL, customer, NULL);
        sleep(rand() % 3); // Random delay for customer arrivals
    }

    // Wait for all customers to finish
    for (int i = 0; i < numCustomers; ++i) {
        pthread_join(customerThreads[i], NULL);
    }

    // Notify barbers that work is done
    pthread_mutex_lock(&mutex);
    totalCustomers = 0;
    pthread_cond_signal(&customerReady);
    pthread_mutex_unlock(&mutex);

    // Wait for all barbers to finish
    for (int i = 0; i < NUM_BARBERS; ++i) {
        pthread_join(barberThreads[i], NULL);
    }

    // Clean up resources
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&barberSleep);
    pthread_cond_destroy(&customerReady);

    return 0;
}
