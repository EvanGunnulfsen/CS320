#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include "zemaphore.h" // Custom semaphore library

int N;                 // Number of philosophers
Zem_t *forks;          // Semaphores for forks
Zem_t table;           // Semaphore for table limit (used in algorithm 3)

int algorithm_choice;  // Chosen algorithm for solving the dining philosophers problem

void *philosopher(void *arg) {
    int id = *(int *)arg;  // Get philosopher ID
    free(arg);             // Free allocated memory for the ID

    while (1) {
        // Thinking
        printf("Philosopher %d is thinking.\n", id);
        sleep(rand() % 3 + 1); // Simulate thinking time

        // Hungry
        printf("Philosopher %d is hungry.\n", id);

        // Try to pick up forks based on the chosen algorithm
        if (algorithm_choice == 1) {
            // algo 1
            Zem_wait(&forks[id]);                // Pick up left fork
            Zem_wait(&forks[(id + 1) % N]);      // Pick up right fork
        } else if (algorithm_choice == 2) {
            // Pick both forks only if both are free, algo 2
            while (1) {
                Zem_wait(&forks[id]);            // Try to pick up left fork
                if (pthread_mutex_trylock(&forks[(id + 1) % N].lock) == 0) { 
                    break;                       // Got right fork
                } else {
                    Zem_post(&forks[id]);        // Put down left fork if right fork unavailable
                    usleep(1000);               // Wait and retry
                }
            }
        } else if (algorithm_choice == 3) {
            // Limit to N-1 philosophers at the table, algo 3
            Zem_wait(&table);                   // Wait for table space
            Zem_wait(&forks[id]);               // Pick up left fork
            Zem_wait(&forks[(id + 1) % N]);     // Pick up right fork
        }

        // Eating
        printf("Philosopher %d is eating.\n", id);
        sleep(rand() % 3 + 1); // Simulate eating time

        // Put down forks
        Zem_post(&forks[id]);                   // Release left fork
        Zem_post(&forks[(id + 1) % N]);         // Release right fork

        if (algorithm_choice == 3) {
            Zem_post(&table);                   // Leave the table
        }

        printf("Philosopher %d is done eating.\n", id);
    }
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        // Show usage and algorithm options
        printf("Usage: %s <number_of_philosophers> <algorithm_choice>\n", argv[0]);
        printf("Algorithm Choices:\n");
        printf("1 - Pick left fork, then right fork (deadlock-prone)\n");
        printf("2 - Pick both forks if both are available\n");
        printf("3 - Only N-1 philosophers allowed at the table\n");
        return -1;
    }

    // Parse inputs
    N = atoi(argv[1]);
    algorithm_choice = atoi(argv[2]);

    // Validate inputs
    if (N < 3 || N > 20) {
        printf("Number of philosophers must be between 3 and 20.\n");
        return -1;
    }
    if (algorithm_choice < 1 || algorithm_choice > 3) {
        printf("Invalid algorithm choice. Choose 1, 2, or 3.\n");
        return -1;
    }

    // Initialize forks and table
    forks = malloc(N * sizeof(Zem_t));
    for (int i = 0; i < N; ++i) {
        Zem_init(&forks[i], 1); // Each fork is available initially
    }
    if (algorithm_choice == 3) {
        Zem_init(&table, N - 1); // Limit table to N-1 philosophers
    }

    // Create threads for philosophers
    pthread_t philosophers[N];
    for (int i = 0; i < N; ++i) {
        int *id = malloc(sizeof(int)); // Allocate ID for the philosopher
        *id = i;
        pthread_create(&philosophers[i], NULL, philosopher, id);
    }

    // Wait for threads (though they run indefinitely)
    for (int i = 0; i < N; ++i) {
        pthread_join(philosophers[i], NULL);
    }

    // Clean up
    free(forks);
    return 0;
}
